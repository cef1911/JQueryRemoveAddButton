     $("#rightIcon").button({
                icons: {
                    primary: 'ui-icon-blank',
                    secondary: 'ui-icon-triangle-1-s'
                }
            });